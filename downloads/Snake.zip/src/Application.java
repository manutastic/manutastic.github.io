package manuodelrio;

import java.awt.*;
import javax.swing.*;

public class Application extends JFrame{
	
	public Application() {
		initUI();
	}
	
	private void initUI(){
		//make new instance of Board
		add(new Board());
		
		setSize(498, 487);
		
		
		setTitle("Snake Game");
		//Close window when 'x' button is clicked
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//Open window at center of screen.
		setLocationRelativeTo(null);
	}

	public static void main(String[] args) {
		//Make instance of Application and make it visible:
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				Application ex = new Application();
				ex.setVisible(true);
			}
		});

	}

}