package manuodelrio;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.geom.Rectangle2D;

import javax.swing.*;

public class Board extends JPanel implements ActionListener{

	private final int DOTSIZE = 20;
	private final int ALL_DOTS = 900;
	private final int SPEED = 140;

	private boolean leftDirection = false;
	private boolean rightDirection = false;
	private boolean upDirection = false;
	private boolean downDirection = false;

	private boolean inGame = true;

	private final int x[] = new int[ALL_DOTS];
	private final int y[] = new int[ALL_DOTS];

	private int dots;
	private int appleX;
	private int appleY;
	private int score;
	private int highScore;

	private Timer timer;


	//Override paintComponent of JPanel

	public Board() {
		setFocusable(true);
		requestFocus();
		requestFocusInWindow();
		addKeyListener(new TAdapter());
		initGame();
	}

	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g); //calling the parent to reset
		//Set BG color
		setBackground(Color.black);
		renderGraphics(g);
	}

	public void drawCenteredString(String s, int w, int h, Graphics g) {
		FontMetrics fm = g.getFontMetrics();
		int x = (w - fm.stringWidth(s)) / 2;
		int y = (fm.getAscent() + (h - (fm.getAscent() + fm.getDescent())) / 2);
		g.drawString(s, x, y);
	}

	private void renderGraphics(Graphics g){
		//Graphics2D extends Graphics, better for 2D
		Graphics2D g2 = (Graphics2D) g;

		if(inGame) {

			// Render snake
			for(int z = 0; z< dots; z++){
				Rectangle2D rect = new Rectangle2D.Double(x[z], y[z], DOTSIZE, DOTSIZE);
				g2.setColor(Color.WHITE);
				g2.fill(rect);
			}

			// Render apple
			Rectangle2D rect = new Rectangle2D.Double(appleX, appleY, DOTSIZE, DOTSIZE);
			g2.setColor(Color.red);
			g2.fill(rect);

		}else{
			//Game Over.
			if (score > highScore){
				highScore = score;
			}
			
			Dimension d = this.getSize();
			g.setColor(Color.WHITE);
			
			g.setFont(new Font("system", Font.PLAIN, 70));
			drawCenteredString(score + "", d.width, d.height-200, g);
			
			g.setFont(new Font("system", Font.PLAIN, 20));
			drawCenteredString("Best: " + highScore, d.width, d.height-90, g);
			
			g.setFont(new Font("system", Font.PLAIN, 35));
			drawCenteredString("Game Over.", d.width, d.height+80, g);
			
			g.setFont(new Font("system", Font.PLAIN, 16));
			drawCenteredString("Press Any Key to Restart", d.width, d.height+150, g);
			
		}
	}

	private void initGame() {
		
		// Reset direction input
		upDirection = false;
		downDirection = false;
		rightDirection = false;
		leftDirection = false;
	
		//Reset score
		score = 0;

		// Set initial length of the snake.
		dots = 1;

		// Set the initial position of the dots.
		for (int z = 0; z<dots; z++){
			x[z] = 20 - z * 20;
			y[z] = 20;
		}

		// Set the initial position of the apple.
		setApple();

		timer = new Timer(SPEED, this);
		timer.start();
	}

	private void setApple() {
		do {
			appleX = (int)Math.round(Math.random() * 23) * DOTSIZE;
			appleY = (int)Math.round(Math.random() * 21) * DOTSIZE;
		} while (appleInSnake()); //To make sure the apple doesn't appear in the body of the snake.
	}

	public boolean appleInSnake() {
		// Check if the position of the apple is in the body of the snake.
		for (int z = 0; z<dots; z++){
			if (appleX == x[z] && appleY == y[z]){
				return true;
			}
		}
		return false;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		move();
		checkGameOver();
		checkApple();
		repaint();
	}

	private void checkGameOver() {
		for (int z = 1; z<dots; z++){
			if (x[0] == x[z] && y[0] == y[z]){
				timer.stop();
				inGame = false;
			}
		}
		if (x[0] > 460 || y[0] > 420 || x[0] < 0 || y[0] < 0) {
			timer.stop();
			inGame = false;
		}
	}

	private void checkApple() {
		if (appleX == x[0] && appleY == y[0]){
			setApple();
			dots++;
			score++;
		}
	}

	private void move() {

		// Move every dot in the chain up by one.
		for (int z = dots; z > 0; z--){
			x[z] = x[(z - 1)];
			y[z] = y[(z - 1)];
		}

		// Move the head according to the arrow presses.
		if(leftDirection){
			x[0] -= DOTSIZE;
		}
		if(rightDirection){
			x[0] += DOTSIZE;
		}
		if(upDirection){
			y[0] -= DOTSIZE;
		}
		if(downDirection){
			y[0] += DOTSIZE;
		}
	}

	private class TAdapter extends KeyAdapter {

		@Override
		public void keyPressed(KeyEvent e) {

			int key = e.getKeyCode();

			if (inGame) {

				if ((key == KeyEvent.VK_LEFT) && (!rightDirection)){
					leftDirection = true;
					upDirection = false;
					downDirection = false;
				}

				if ((key == KeyEvent.VK_RIGHT) && (!leftDirection)){
					rightDirection = true;
					upDirection = false;
					downDirection = false;
				}

				if ((key == KeyEvent.VK_UP) && (!downDirection)){
					upDirection = true;
					rightDirection = false;
					leftDirection = false;
				}

				if ((key == KeyEvent.VK_DOWN) && (!upDirection)){
					downDirection = true;
					rightDirection = false;
					leftDirection = false;
				}

			} else {

				inGame = true;
				initGame();
			}
		}
	}
}

