import pygame, sys, random, os
from pygame import *

pygame.init()


# Colors: 
RED = (242, 95, 92)
RED_TEXT = (209, 37, 35)
RED_OUTLINE = (255, 154, 152)

GREEN = (112, 193, 135)
GREEN_TEXT = (79, 174, 99)
GREEN_OUTLINE = (136, 234, 164)

BLUE = (56, 145, 183)
BLUE_TEXT = (39, 112, 160)
BLUE_OUTLINE = (78, 202, 255)

YELLOW = (255, 224, 102)
YELLOW_TEXT = (233, 189, 39)
YELLOW_OUTLINE = (255, 246, 209)

BG_COLOR = (55, 56, 54)
WHITE =  (254, 254, 254)

# Vars
WINDOW_SIZE = 600
FPS = 30
clock = pygame.time.Clock()
BUTTON_SIZE = 200
BUTTON_GAP = 10
MARGIN = int((WINDOW_SIZE - (2*BUTTON_SIZE) - BUTTON_GAP)/2)

screen=pygame.display.set_mode((WINDOW_SIZE, WINDOW_SIZE),0,32) 

# Font
BITTERFONT = pygame.font.Font('Bitter-Regular.otf', 30)
BITTERFONTBIG = pygame.font.Font('Bitter-Regular.otf', 84)

# Sound
BEEP1 = pygame.mixer.Sound('beep1.ogg')
BEEP2 = pygame.mixer.Sound('beep2.ogg')
BEEP3 = pygame.mixer.Sound('beep3.ogg')
BEEP4 = pygame.mixer.Sound('beep4.ogg')

#Buttons
GREEN_BUTTON = pygame.Rect(MARGIN, MARGIN, BUTTON_SIZE, BUTTON_SIZE)
RED_BUTTON = pygame.Rect(MARGIN + BUTTON_SIZE + BUTTON_GAP, MARGIN, BUTTON_SIZE, BUTTON_SIZE)
BLUE_BUTTON = pygame.Rect(MARGIN, MARGIN + BUTTON_SIZE + BUTTON_GAP, BUTTON_SIZE, BUTTON_SIZE)
YELLOW_BUTTON = pygame.Rect( MARGIN + BUTTON_SIZE + BUTTON_GAP, MARGIN + BUTTON_SIZE + BUTTON_GAP, BUTTON_SIZE, BUTTON_SIZE)

def main():

	# Computer's Pattern
	computerPattern = []
	currentStep = 0
	score = 0

	waitingForUserInput = False

	while True:
		clickedButton = None

		#Clear the screen
		screen.fill(BG_COLOR)

		# Render the four buttons
		DrawButton(screen, GREEN_BUTTON, GREEN, GREEN_OUTLINE, "A", GREEN_TEXT)
		DrawButton(screen, RED_BUTTON, RED, RED_OUTLINE, "S", RED_TEXT)
		DrawButton(screen, BLUE_BUTTON, BLUE, BLUE_OUTLINE, "Z", BLUE_TEXT)
		DrawButton(screen, YELLOW_BUTTON, YELLOW, YELLOW_OUTLINE, "X", YELLOW_TEXT)

		# Render the Score counter
		scoreText = BITTERFONT.render('Score: ' + str(score), 1, WHITE)
		scoreRect = scoreText.get_rect()
		scoreRect.topleft = (WINDOW_SIZE/2 - scoreRect.width/2, 30)
		screen.blit(scoreText, scoreRect)

		for event in pygame.event.get():
			if event.type == QUIT:                                                    
				pygame.quit()
				sys.exit()
			elif event.type == MOUSEBUTTONUP:
				mousex, mousey = event.pos
				clickedButton = getButtonClicked(mousex, mousey)
			elif event.type == KEYDOWN:
				if event.key==K_ESCAPE:
					pygame.quit()
				elif event.key == K_a:
					clickedButton = GREEN
				if event.key ==K_s:
					clickedButton = RED
				if event.key ==K_z:
					clickedButton = BLUE
				if event.key ==K_x:
					clickedButton = YELLOW

		if not waitingForUserInput:
			# Add to pattern
			pygame.display.update()
			pygame.time.wait(500)
			computerPattern.append(random.choice((GREEN, RED, BLUE, YELLOW)))
			# Play the pattern
			for button in computerPattern:
				buttonAnimation(button)
				pygame.time.wait(200)
			waitingForUserInput = True;
		else:
			if clickedButton and clickedButton == computerPattern[currentStep]:
				currentStep += 1
				buttonAnimation(clickedButton)
				if currentStep == len(computerPattern):
					score += 1
					waitingForUserInput= False;
					currentStep = 0
			elif clickedButton and clickedButton != computerPattern[currentStep]:
				gameOver()
				computerPattern = []
				currentStep = 0
				waitingForUserInput = False
				score = 0


		pygame.display.update()

		#Limit Clock
		clock.tick(FPS)

		#Flip to the screen
		pygame.display.flip()

	pygame.quit()

def buttonAnimation(button):
	if button == YELLOW:
		sound = BEEP1
		rectangle = YELLOW_BUTTON
	elif button == BLUE:
		sound = BEEP2
		rectangle = BLUE_BUTTON
	elif button == RED:
		sound = BEEP3
		rectangle = RED_BUTTON
	elif button == GREEN:
		sound = BEEP4
		rectangle = GREEN_BUTTON
	
	sound.play()

	origScreen = screen.copy()
	flashScreen = pygame.Surface((BUTTON_SIZE, BUTTON_SIZE))
	flashScreen = flashScreen.convert_alpha()
	r, g, b = WHITE
	sound.play()
	for start, end, step in ((0, 255, 1), (255, 0, -1)): # animation loop
		for alpha in range(start, end, 50 * step):
			screen.blit(origScreen, (0, 0))
			flashScreen.fill((r, g, b, alpha))
			screen.blit(flashScreen, rectangle.topleft)
			pygame.display.update()
			clock.tick(FPS)
	screen.blit(origScreen, (0, 0))


def gameOver():
	rectangle = pygame.Rect(0, 0, WINDOW_SIZE, WINDOW_SIZE)
	origScreen = screen.copy()
	flashScreen = pygame.Surface((WINDOW_SIZE, WINDOW_SIZE))
	flashScreen = flashScreen.convert_alpha()
	r, g, b = WHITE
	BEEP4.play()
	BEEP3.play()
	BEEP2.play()
	BEEP1.play()
	for start, end, step in ((0, 255, 1), (255, 0, -1)): # animation loop
		for alpha in range(start, end, 50 * step):
			screen.blit(origScreen, (0, 0))
			flashScreen.fill((r, g, b, alpha))
			screen.blit(flashScreen, rectangle.topleft)
			pygame.display.update()
			clock.tick(FPS)
	screen.blit(origScreen, (0, 0))
	print("Game Over")

def getButtonClicked(mousex, mousey):
	if (mousex <= MARGIN + BUTTON_SIZE and mousex >= MARGIN):
		if(mousey >= MARGIN and mousey <= MARGIN + BUTTON_SIZE):
			return GREEN
		if(mousey >= MARGIN + BUTTON_SIZE + BUTTON_GAP and mousey < MARGIN + BUTTON_SIZE*2 + BUTTON_GAP):
			return BLUE
	if(mousex >= MARGIN + BUTTON_SIZE + BUTTON_GAP and mousex < MARGIN + BUTTON_SIZE*2 + BUTTON_GAP):
		if(mousey >= MARGIN and mousey <= MARGIN + BUTTON_SIZE):
			return RED
		if(mousey >= MARGIN + BUTTON_SIZE + BUTTON_GAP and mousey < MARGIN + BUTTON_SIZE*2 + BUTTON_GAP):
			return YELLOW

def DrawButton(surface, rect, color, outline_color, letter, letter_color):
	rect_outline = pygame.Rect(rect.x-1, rect.y-1, rect.width+2, rect.height+2)
	AAfilledRoundedRect(surface, rect_outline, outline_color)
	AAfilledRoundedRect(surface, rect, color)

	letterText = BITTERFONTBIG.render(letter, 1, letter_color)
	letterRect = letterText.get_rect()
	letterx = rect.x + (rect.width-letterRect.width)/2
	lettery = rect.y + (rect.height-letterRect.height)/2
	letterRect.topleft = (letterx, lettery)
	surface.blit(letterText, letterRect)

def AAfilledRoundedRect(surface,rect,color,radius=0.03):

	"""
	AAfilledRoundedRect(surface,rect,color,radius=0.4)

	surface : destination
	rect    : rectangle
	color   : rgb or rgba
	radius  : 0 <= radius <= 1
	"""

	rect         = Rect(rect)
	color        = Color(*color)
	alpha        = color.a
	color.a      = 0
	pos          = rect.topleft
	rect.topleft = 0,0
	rectangle    = Surface(rect.size,SRCALPHA)

	circle       = Surface([min(rect.size)*3]*2,SRCALPHA)
	draw.ellipse(circle,(0,0,0),circle.get_rect(),0)
	circle       = transform.smoothscale(circle,[int(min(rect.size)*radius)]*2)

	radius              = rectangle.blit(circle,(0,0))
	radius.bottomright  = rect.bottomright
	rectangle.blit(circle,radius)
	radius.topright     = rect.topright
	rectangle.blit(circle,radius)
	radius.bottomleft   = rect.bottomleft
	rectangle.blit(circle,radius)

	rectangle.fill((0,0,0),rect.inflate(-radius.w,0))
	rectangle.fill((0,0,0),rect.inflate(0,-radius.h))

	rectangle.fill(color,special_flags=BLEND_RGBA_MAX)
	rectangle.fill((255,255,255,alpha),special_flags=BLEND_RGBA_MIN)

	return surface.blit(rectangle,pos)

main()